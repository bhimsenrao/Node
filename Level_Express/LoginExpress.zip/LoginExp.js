var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var connection=require('./config');


// Create application/x-www-form-urlencoded parser

var urlencodedParser = bodyParser.urlencoded({ extended: false })

//app.use(express.static('public'));

app.get('/Login.html', function (req, res) {
   res.sendFile( __dirname + "/" + "Login.html" );
})

app.post('/userLogin', urlencodedParser, function (req, res) {
   // Prepare output in JSON format
res.writeHeader(200, {"Content-Type": "text/html"});  
   var username=req.body.uname;
   var password=req.body.pword;
//   var pass=cryptr.decrypt(results[0].password); 
     connection.query('select * from user where userid=?',[username],funtion(error,results,fields){
            if(error){
               res.write("Failed to connect");

            }else   if(username==='raju'){
             // here you replace with following
             /*
               if(results.length >0){
             
            if(username===results[0].username){
               res.write("Valid user");
            }else{
 res.write("Invalid user");             
}
*/
              res.write("welcome<br>");
            }
});
             response = {
                  first_name:req.body.uname,
                  last_name:req.body.pword
             };
   console.log(response);
   res.end(JSON.stringify(response));
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})